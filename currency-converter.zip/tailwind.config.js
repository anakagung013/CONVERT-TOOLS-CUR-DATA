module.exports = {
    content: [
      "./src/**/*.{js,jsx,ts,tsx}", // Pastikan jalur ini sesuai dengan struktur proyek Anda
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  }
  